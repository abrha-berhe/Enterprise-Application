package miu.edu.SpringB2.CRUDSpringB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudSpringBApplicationTests {

	@Test
	void contextLoads() {
	}

}
